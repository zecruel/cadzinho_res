12.03.2018 � Technical Support Services
THE CAD STANDARDS EXTERNAL REQUIREMENTS ARE WORKING DOCUMENTS AND MAY BE REVISED OFTEN, PLEASE VERIFY YOU HAVE THE MOST CURRENT AVAILABLE BEFORE STARTING A NEW PROJECT.

Description of files:

1_CAD Standards - External Requirements - documented requirements for Main Extensions, Licenses & Easements and Capital Projects (see specific section related to the work being completed).
	CAD Standards - External Requirements 
	CAD Standards - External Requirements - Appendix A.pdf
	CAD Standards - External Requirements - Appendix B.xlsx
	CAD Standards - External Requirements - Appendix C.pdf

2_Fonts - Fonts required for creating drawings with provided files (typical default fonts included with Windows and AutoCAD).
	acad.fmp
	arial.ttf
	CALIBRI.TTF
	ltypeshp.shx
	simplex.shx
	txt.shx

3_CTB and Linetypes - Color table used for Licenses and Easements drawings and Denver Water linetypes.
	DW_Engineering.ctb
	DW_linetypes.lin

4_Blocks and Layers - Denver Water drawing provided to help create main extension drawings, blocks and layers included. Standards file included to verify drawings settings. Templates with titleblocks not provided, please use your company's own templates for plan review submission.
	MainExtension.dwg
	MainExtension.dws

Note: for any questions or concerns please email CADStandards@denverwater.org.

