extern		scanfont();
extern int	getline();
